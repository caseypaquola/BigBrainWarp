try:
    from enigmalexer import EnigmaLexerStyle
except ImportError:
    from .enigmalexer import EnigmaLexerStyle
